package biblioteca;

import javax.swing.*;
import java.awt.event.*;

public class TelaPenalidade {
    
}
